package com.ggs.traveljava.controller;

import com.ggs.traveljava.dto.ChatRequestDTO;
import com.ggs.traveljava.dto.TravelRequestDTO;
import com.ggs.traveljava.service.TravelService;
import com.ggs.traveljava.vo.TravelRecommendVO;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import com.ggs.traveljava.vo.Result;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;


@RestController
@RequestMapping("/api/travel")
@RequiredArgsConstructor //这个注解也是初始化final类型的字段
public class TravelController {
    private final TravelService travelService;

//    public TravelController(TravelService travelService) {
//        this.travelService = travelService;
//    }

    @GetMapping("/hello")
    public Result<String> hello() {

        return Result.ok("hello world");
    }

//    @valid开启参数校验
    @PostMapping("/recommend")
    public Result<TravelRecommendVO> recommend(@Valid @RequestBody TravelRequestDTO travelRequestDTO) {

        System.out.println(travelRequestDTO.getCity());
        System.out.println(travelRequestDTO.getDays());
        System.out.println(travelRequestDTO.getBudget());
        TravelRecommendVO travelRecommendVO = travelService.recommend(travelRequestDTO.getCity(), travelRequestDTO.getDays(), travelRequestDTO.getBudget());
        return Result.ok(travelRecommendVO);
    }
    @PostMapping(value = "/chat", produces = "text/event-stream")
    public SseEmitter chat(@Valid @RequestBody ChatRequestDTO chatRequestDTO){
        return travelService.chat(chatRequestDTO.getMessage());
    }

}
